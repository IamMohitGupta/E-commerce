<?php
	$product_name=$_POST['product_name'];
	$price=$_POST['product_price'];
	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	
?>