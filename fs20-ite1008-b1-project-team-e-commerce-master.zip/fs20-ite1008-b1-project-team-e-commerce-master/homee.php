<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="author" content="Dhruvil">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
	<title>Home Page-CORO-FY</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link rel="stylesheet" href="boot.css">
</head>
<body>
<!--
<nav class="navbar navbar-expand-md bg-dark navbar-dark">

  <a class="navbar-brand" href="#">Coro-Fy</a>

  Toggler/collapsibe Button  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

   Navbar links 
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.html">Sign In</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="signup.html">Sign Up</a>
      </li>
    </ul>
  </div>
</nav>
	 -->
	 <div class="jumbotron">
      <h1 class="display-3">Your one stop for Covid protection</h1>
      <h3 class="lead">We care for you and your needs ;)</h3>
      <hr class="my-2">
      <p class="lead">
        <a  type="button" class="btn btn-danger" href="signup.html" role="button"> Sign Up </a>
        <a  type="button" class="btn btn-warning"	 href="login.php" role="button">Sign In </a>
      </p>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!--<a class="navbar-brand" href="#">Navbar</a>-->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">My Cart</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Covid_predictor_pg1.html">Covid Predictor</a>
						</li>
						<li class="nav-item">
              <a class="nav-link" href="stats.html">Covid Stats</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="info.html">Info</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
          </ul>
          <!--<form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>-->
        </div>
      </nav>
    </div>
	<?php

session_start();
ob_start();
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="shopping"; // Database name 
$tbl_name="user"; // Table name 

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password", "$db_name")or die("cannot connect"); 

// Define $myusername and $mypassword 
$myusername=$_POST['username']; 
$mypassword=$_POST['password']; 

// To protect MySQL injection

$sql="SELECT * FROM $tbl_name WHERE email='$myusername' and password='$mypassword'";
$result=mysqli_query($conn,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){

// Register $myusername, $mypassword and redirect to file "login_success.php"
$_SESSION['username'] = $username;
$_SESSION['password'] = $password;
$query = "Select username from user where email='$myusername' and password='$mypassword'";
$res = mysqli_query($conn,$query);
if ($result->num_rows == 1) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
	echo '<div class="alert alert-info align-middle" >';
	echo '<h1 class="display-5">Welcome '.$row["username"].' ! </h1>';
	echo"</div>";
//header("location:index1.php");
}
}
}
else {
echo "Wrong Email or Password";
}
ob_end_flush();
?>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<style type="text/css">
*{
margin:0 20px;
font-weight:10;
}
.alert{
border-radius:10px;
margin: 20px auto;
}
</style>
</head>
<body>
</body>
</html>
<?php
	require 'config.php';
	$sql="SELECT * FROM product";
	$result=mysqli_query($conn,$sql);
?>
<div class="container">
	<div class="row">
		<?php
		while($row=mysqli_fetch_array($result)){
		?>
		<div class="col-lg-4 mt-3 mb-3">
			<div class="card-deck">
				<div class="card border">
					<img src="<?= $row['product_image']; ?>" class="card-iamge-top" height="320">
					<h5 class="card-title">Product : <?= $row['product_name']; ?></h5>
          <button type="submit" class="btn btn-warning btn-block btn-lg">Add to cart</button>
					<a href="order.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-block btn-lg">Buy Now</a>

				</div>
			</div>
		</div>

	<?php } ?>
	</div>
</div>
<!--  Page Footer -------------------------------------------------------->
<footer class="page-footer font-small-blue">
  <div class="team">
    <h3>Our Team</h3>
    <ul>
    <li>Shreyash vardhan</li>
    <li>Dhruvil Dave</li>
    <li>Kumar Abhijeet</li>
    <li>Mohit Gupta</li>
  </ul>
  </div>
  
  
</footer> 

</body>
</html>
